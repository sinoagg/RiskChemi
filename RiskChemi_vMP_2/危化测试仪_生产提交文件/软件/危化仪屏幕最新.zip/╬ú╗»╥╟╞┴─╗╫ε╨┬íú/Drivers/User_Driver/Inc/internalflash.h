#ifndef __INTERNALFLASH_H
#define __INTERNALFLASH_H

#include "stm32f1xx_hal.h"
#include "prj_typedef.h"

#define FLASH_USER_START_ADDR        ((uint32_t)0x0801F800)   /* Start @ of user Flash area */
#define FLASH_USER_END_ADDR          ((uint32_t)0x0801FFFF)   /* End   @ of user Flash area */
#define FLASH_USER_PAGE1_START_ADDR  ((uint32_t)0x0801F800)   /* Start Page1 @ of user Flash area */
#define FLASH_USER_PAGE1_END_ADDR    ((uint32_t)0x0801FBFF)   /* End Page1 @ of user Flash area */
#define FLASH_USER_PAGE2_START_ADDR  ((uint32_t)0x0801FC00)
#define FLASH_USER_PAGE2_END_ADDR  	 ((uint32_t)0x0801FFFF)

#define DATA_ADDR 0x00            	

void GetFlashData_Float(Float_Union_Data* pDataArray, uint32_t flash_addr, uint8_t length);
void GetFlashData_U32(uint32_t* pdata, uint32_t flash_addr, uint8_t length);

static uint32_t FlashRead32bit(uint32_t ReadAddr);
static void Uint32to4Uint8(uint32_t uint32_data, uint8_t* pBuffer);
void FlashErase(uint32_t start_address,uint32_t end_address);   //����flash�û�ҳ

#endif









