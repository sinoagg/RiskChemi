#include "tft.h"

void TFT_Init(void)
{
	HAL_GPIO_WritePin(GPIOB, Buzzer_Pin, GPIO_PIN_RESET);
	TFT_StartWairning(FRONT_LEFT, HIDE);
	TFT_StartWairning(FRONT_RIGHT, HIDE);
	TFT_StartWairning(REAR_LEFT, HIDE);
	TFT_StartWairning(REAR_RIGHT, HIDE);
	TFT_StartWairning(SEAT_NUM1, HIDE);
	TFT_StartWairning(SEAT_NUM2, HIDE);
	TFT_StartWairning(SEAT_NUM3, HIDE);
	TFT_StartWairning(SEAT_NUM4, HIDE);
}

/*ǰ���ű��� 60ǰ��1�� 62ǰ��2�� 64����1�� 66����2�� ��1 �ر�0*/
void TFT_StartWairning(uint8_t pos_addr, uint8_t state)
{
	uint8_t TFT_SWCOMMAND[8]={0x5A,0xA5,0x05,0x82,0x10,0x00,0x00,0x01};
	TFT_SWCOMMAND[5]=pos_addr;
	TFT_SWCOMMAND[7]=state;
	HAL_UART_AbortReceive_IT(&huart2);
	HAL_UART_Transmit(&huart2, TFT_SWCOMMAND, 8, 1000);
	while(HAL_UART_Receive(&huart2,TFT_ACK,6,2000)!=HAL_OK);
	HAL_UART_Receive_IT(&huart2, TFT_RxBuf, 11);
}

/*������ʪ��ֵ*/
void TFT_TransTemHumi(uint16_t tem,uint16_t humi)
{
	uint8_t TFT_THCOMMAND[8]={0x5A,0xA5,0x05,0x82,0x10,0x6A,0x00,0x00};
	uint8_t TFT_TTCOMMAND[8]={0x5A,0xA5,0x05,0x82,0x10,0x6B,0x00,0x00};
	TFT_TTCOMMAND[6]=((tem&0xFF00)>>8);
	TFT_TTCOMMAND[7]=(tem&0x00FF);
	HAL_UART_AbortReceive_IT(&huart2);
	HAL_UART_Transmit(&huart2, TFT_TTCOMMAND, 8, 1000);
	while(HAL_UART_Receive(&huart2,TFT_ACK,6,2000)!=HAL_OK);
	HAL_UART_Receive_IT(&huart2, TFT_RxBuf, 11);
	TFT_THCOMMAND[6]=((humi&0xFF00)>>8);
	TFT_THCOMMAND[7]=(humi&0x00FF);
	HAL_Delay(10);
	HAL_UART_AbortReceive_IT(&huart2);
	HAL_UART_Transmit(&huart2, TFT_THCOMMAND, 8, 1000);
	while(HAL_UART_Receive(&huart2,TFT_ACK,6,2000)!=HAL_OK);
	HAL_UART_Receive_IT(&huart2, TFT_RxBuf, 11);
}


