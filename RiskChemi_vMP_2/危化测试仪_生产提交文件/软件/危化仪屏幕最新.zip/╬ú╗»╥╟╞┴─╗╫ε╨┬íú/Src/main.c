/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2017 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.   88
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_hal.h"

/* USER CODE BEGIN Includes */
#include "can.h"
#include "delay.h"
#include "wirespi.h"
#include "cmt2219a.h"
#include "tft.h"
#include "internalflash.h"
#include "prj_typedef.h"

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
#define WIFI_RX_LEN 12
#define WIRE_TRUE 1                           //�жϷ������յ�������
#define WIRE_FALSE 0                          //δ�յ�����
#define ALARM_ON 1                            //��������
#define ALARM_OFF 0                           //�رձ���
#define CAN_TX_LEN 8													//CAN���䳤��
#define CAN_ID 0x18FEE9D8

extern uint8_t CfgTbl[];                      //�������ñ�����
extern uint8_t frame_valid;                   //���߽����жϱ�־

uint8_t WIFI_RxBuf[WIFI_RX_LEN]={0};          //���߽��ջ�������
uint8_t TFT_RxBuf[11]={0};                     //���ڽ��ջ�������
uint8_t TFT_ACK[6]={0};
SensorsTypeDef hsensor;

uint8_t alarm_pos=0;                          //����Σ��Ʒλ��ֵ
uint16_t alarm_cnt=0;													//������ʱ	
uint8_t alarm_state=ALARM_ON;                //����״̬
uint8_t alarm_volume=ALARM_ON;                //��������
uint8_t value_xor=0;                          //���ֵУ��
float front_alarm_value=0.01;                 //ǰ�ű�����ֵ
float rear_alarm_value=0.01;                  //���ű�����ֵ
float alarm_value=0.01;                       //������ֵ
uint16_t tim2_cnt=0;

cmt2219aClass radio;                          //����ģ������

CAN_FilterConfTypeDef  sFilterConfig;
//CanTxMsgTypeDef TxMessage;                    //can���͵���Ϣ
//CanRxMsgTypeDef RxMessage;                    //can���յ���Ϣ

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_CAN_Init(void);
static void MX_TIM2_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
void vCMT2219_Setup(void);

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */


/* USER CODE END 0 */
uint8_t Alarm_level=0;
uint8_t waring_level_flag=0;//���������־
int main(void)
{

  /* USER CODE BEGIN 1 */
	uint8_t selfcheck_state=0;                   //can�Ƿ��Լ�
	uint8_t selfcheck_cnt=0;                     //�Լ��������
  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_CAN_Init();
  //MX_TIM2_Init();

  /* USER CODE BEGIN 2 */
	//HAL_TIM_Base_Start(&htim2);
	hsensor.HUMI.number_float=50;
	hsensor.TEMP.number_float=20;
	CAN_TX_Init(&hcan, CAN_ID);
	Delay_Init(fac_us);                           //����us��ʱ��ʼ������
	vCMT2219_Setup();                             //��������ģ�����
	MyCAN_FilterConf(&hcan,&sFilterConfig);       //����CAN�������鲢ʹ�ܽ����ж�
	//HAL_UART_Receive_IT(&huart2, TFT_RxBuf, 11);
	//TFT_TransTemHumi((uint16_t)hsensor.TEMP.number_float,(uint16_t)hsensor.HUMI.number_float);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
		HAL_UART_Receive_IT(&huart2, TFT_RxBuf, 11);
		if(frame_valid==WIRE_TRUE)
		{
			HAL_GPIO_WritePin(GPIOB, LED0_Pin, GPIO_PIN_RESET);
			HAL_NVIC_DisableIRQ(EXTI2_IRQn);               //�ر��ⲿ�жϼ����߽����ж�
			frame_valid=WIRE_FALSE;                        //�ⲿ�жϱ�־����
		  bCMT2219_GetMessage(WIFI_RxBuf, WIFI_RX_LEN);  //��ȡ������
			value_xor=0;
			for(uint8_t i=0;i<WIFI_RX_LEN-1;i++)                      //У����յ�������
			{
				value_xor^=WIFI_RxBuf[i];
				
			}
			if(WIFI_RxBuf[WIFI_RX_LEN-1]==value_xor&&value_xor!=0)//������ܵ���ȷ��֡ͷ��Ϣ���Ҳ���ȫ0��������
			{
				//ֻ�ս����¶�ʪ������
				hsensor.TEMP.number_uchar[3]=WIFI_RxBuf[3];
				hsensor.TEMP.number_uchar[2]=WIFI_RxBuf[4];
				hsensor.TEMP.number_uchar[1]=WIFI_RxBuf[5];
				hsensor.TEMP.number_uchar[0]=WIFI_RxBuf[6];
				hsensor.HUMI.number_uchar[3]=WIFI_RxBuf[7];
				hsensor.HUMI.number_uchar[2]=WIFI_RxBuf[8];
				hsensor.HUMI.number_uchar[1]=WIFI_RxBuf[9];
				hsensor.HUMI.number_uchar[0]=WIFI_RxBuf[10];
				if(WIFI_RxBuf[1]==0x00)			//����Ǳ����ź�
				{
					alarm_pos=WIFI_RxBuf[2];
					if(alarm_pos==1||alarm_pos==2) alarm_value=front_alarm_value;
					else alarm_value=rear_alarm_value;
					if(alarm_state==ALARM_ON)	//����������򿪱���״̬
					{
						waring_level_flag=1;
						alarm_cnt=600;				//feed 3000�� 3000ms ʱ��
					}
				}	
				else if(WIFI_RxBuf[1]==0x01)			//����Ǳ����ź�
				{
					alarm_pos=WIFI_RxBuf[2];
					if(alarm_pos==1||alarm_pos==2) alarm_value=front_alarm_value;
					else alarm_value=rear_alarm_value;
					if(alarm_state==ALARM_ON)	//����������򿪱���״̬
					{
						waring_level_flag=2;
						alarm_cnt=600;				//feed 3000�� 3000ms ʱ��
					}
				}	
				TFT_TransTemHumi((uint16_t)hsensor.TEMP.number_float,(uint16_t)hsensor.HUMI.number_float);
				HAL_GPIO_WritePin(GPIOB, Buzzer_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(GPIOB, LED0_Pin, GPIO_PIN_SET);
			}
			vCMT2219_Setup();
			HAL_NVIC_EnableIRQ(EXTI2_IRQn);                //ʹ���ⲿ�ж�
		}
		//�ж�alarm_cnt����1�뱨��
		if(alarm_cnt>0)
		{
			alarm_cnt--;
			//������������
			if(alarm_volume==ALARM_ON) HAL_GPIO_WritePin(GPIOB, Buzzer_Pin, GPIO_PIN_SET);		//������������Ǵ򿪵�
			else HAL_GPIO_WritePin(GPIOB, Buzzer_Pin, GPIO_PIN_RESET);
			//����ͼ����
      if(waring_level_flag==1)
			{				
			if(alarm_pos==1)      TFT_StartWairning(FRONT_RIGHT, SHOW_level1);
			else if(alarm_pos==2) TFT_StartWairning(FRONT_LEFT, SHOW_level1);
			else if(alarm_pos==3) TFT_StartWairning(REAR_RIGHT, SHOW_level1);
			else if(alarm_pos==4) TFT_StartWairning(REAR_LEFT, SHOW_level1);
			else if(alarm_pos==5) TFT_StartWairning(SEAT_NUM1, SHOW_level1);
			else if(alarm_pos==6) TFT_StartWairning(SEAT_NUM2, SHOW_level1);
			else if(alarm_pos==7) TFT_StartWairning(SEAT_NUM3, SHOW_level1);
			else TFT_StartWairning(SEAT_NUM4, SHOW_level1);
			}
			else if(waring_level_flag==2)
      {				
			if(alarm_pos==1)      TFT_StartWairning(FRONT_RIGHT, SHOW_level2);
			else if(alarm_pos==2) TFT_StartWairning(FRONT_LEFT, SHOW_level2);
			else if(alarm_pos==3) TFT_StartWairning(REAR_RIGHT, SHOW_level2);
			else if(alarm_pos==4) TFT_StartWairning(REAR_LEFT, SHOW_level2);
			else if(alarm_pos==5) TFT_StartWairning(SEAT_NUM1, SHOW_level2);
			else if(alarm_pos==6) TFT_StartWairning(SEAT_NUM2, SHOW_level2);
			else if(alarm_pos==7) TFT_StartWairning(SEAT_NUM3, SHOW_level2);
			else TFT_StartWairning(SEAT_NUM4, SHOW_level2);
			}
			if(alarm_cnt==0)															//����������� 
			{
				TFT_Init();
				HAL_GPIO_WritePin(GPIOB, Buzzer_Pin, GPIO_PIN_RESET); 
			}
		}
		//�ж�tim2_cnt���Լ죬CAN����
		HAL_GPIO_TogglePin(GPIOB, LED0_Pin);
		Delay_us(999);
		tim2_cnt++;
		if((tim2_cnt) == 500)															//�������500ms
		{
			tim2_cnt=0;
			//׼���Լ�״̬
			if(selfcheck_cnt==10)
				selfcheck_state=0;   //�Լ����
			else
			{
				selfcheck_cnt++;
				selfcheck_state=1;   //�����Լ�
				
			}
			
			if(alarm_cnt>0)				// ����б����Ļ�
			{
				//׼����һ�ֽ�����
				if(alarm_pos<5)
				{
				if(alarm_pos<3)
					hcan.pTxMsg->Data[0]=(0x10|selfcheck_state);  //ǰ�ű���
				else
					hcan.pTxMsg->Data[0]=(0x08|selfcheck_state);  //���ű���
				//׼���ڶ��ֽ�����
				(hcan.pTxMsg->Data[1])|=1<<(8-alarm_pos);
			  }
				else
				{
					hcan.pTxMsg->Data[0]=(0x20|selfcheck_state);  //ǰ�ű���
					(hcan.pTxMsg->Data[2])|=1<<(alarm_pos-5);
				}
			}
			else																						//���û�б���
			{
				hcan.pTxMsg->Data[0]=(0x00|selfcheck_state);    //�ޱ���
				hcan.pTxMsg->Data[1]=0;
				hcan.pTxMsg->Data[2]=0;
			}

			hcan.pTxMsg->Data[3]=	(uint16_t)((hsensor.TEMP.number_float+64.f)/0.5);	//�¶�ֵ
			hcan.pTxMsg->Data[4]=(uint16_t)(hsensor.HUMI.number_float/0.5);	//ʪ��ֵ
			
			HAL_CAN_Transmit(&hcan, 1000);
		}
		
	}
  /* USER CODE END 3 */
	
}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* CAN init function */
static void MX_CAN_Init(void)
{
  hcan.Instance = CAN1;
  hcan.Init.Prescaler = 9;
  hcan.Init.Mode = CAN_MODE_NORMAL;
  hcan.Init.SJW = CAN_SJW_1TQ;
  hcan.Init.BS1 = CAN_BS1_7TQ;
  hcan.Init.BS2 = CAN_BS2_8TQ;
  hcan.Init.TTCM = DISABLE;
  hcan.Init.ABOM = DISABLE;
  hcan.Init.AWUM = DISABLE;
  hcan.Init.NART = DISABLE;
  hcan.Init.RFLM = DISABLE;
  hcan.Init.TXFP = DISABLE;
  if (HAL_CAN_Init(&hcan) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7199;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 100;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* USART1 init function */
static void MX_USART1_UART_Init(void)
{

  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* USART2 init function */
static void MX_USART2_UART_Init(void)
{

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, RS485_RE2_Pin|RS485_RE1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, FCSB_Pin|SDA_Pin|CSB_Pin|LED0_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, SCL_Pin|Buzzer_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : RS485_RE2_Pin RS485_RE1_Pin */
  GPIO_InitStruct.Pin = RS485_RE2_Pin|RS485_RE1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : nRSTO_Pin CLKO_Pin */
  GPIO_InitStruct.Pin = nRSTO_Pin|CLKO_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : INT1_Pin */
  GPIO_InitStruct.Pin = INT1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(INT1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : DOUT_Pin */
  GPIO_InitStruct.Pin = DOUT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(DOUT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : FCSB_Pin SCL_Pin SDA_Pin CSB_Pin */
  GPIO_InitStruct.Pin = FCSB_Pin|SCL_Pin|SDA_Pin|CSB_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : Buzzer_Pin LED0_Pin */
  GPIO_InitStruct.Pin = Buzzer_Pin|LED0_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI2_IRQn, 2, 0);
  HAL_NVIC_EnableIRQ(EXTI2_IRQn);

}

/* USER CODE BEGIN 4 */
void vCMT2219_Setup(void)            //�������߽���ģ��
{
  radio.CrcDisable     = SET;
  radio.FixedPktLength = SET;
  radio.NodeDisable    = SET;
  radio.PktLength      = 16;
  vCMT2219_Init(CfgTbl, &radio);
  vCMT2219_GpioFuncCfg(GPIO1_POR|GPIO2_INT1|GPIO3_CLK|GPIO4_DOUT);     //GPIO1Ĭ��ΪnRST��GPIO2Ĭ��ΪINT1��GPIO3��ΪDOUT��GPIO4��ΪDCLK
  
  //vIntSourcCfg((FIFO_WBYTE+OFFSET), 0);                               //Hope�Դ���������
  //vCMT2219_IntOutputCfg(INT1_PIN, 3);
	vCMT2219_IntOutputCfg(INT1_PIN, INT_SOURCE_RX_PACKET_DONE);           //INT1����ж��źţ��ж��ź���ԴΪ����packet���
  vCMT2219_EnableIntSource(0xFF);                                       //ʹ�������ж�
  vCMT2219_GoRx();                                                      //ת�����ģʽ
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance==huart2.Instance)
	{
	  if((TFT_RxBuf[4]==0x30)&&(TFT_RxBuf[7]==0xAA))
		{
			if(TFT_RxBuf[8]==0xB0)      
			{
				if(TFT_RxBuf[9]==0x00)                            //�رձ���
				{ 
					TFT_Init();
					alarm_state=ALARM_OFF;
				}
				else                                              //�򿪱���
					alarm_state=ALARM_ON;
			}
			else if(TFT_RxBuf[8]==0xB1) 
			{
				if(TFT_RxBuf[9]==0x01)                            //�ر�����
				{
					HAL_GPIO_WritePin(GPIOB, Buzzer_Pin, GPIO_PIN_RESET);
					alarm_volume=ALARM_OFF;
				}
				else                                              //������
					alarm_volume=ALARM_ON;
			}
		}
//		HAL_UART_Receive_IT(&huart2, TFT_RxBuf, 11);
	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
		tim2_cnt++;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
