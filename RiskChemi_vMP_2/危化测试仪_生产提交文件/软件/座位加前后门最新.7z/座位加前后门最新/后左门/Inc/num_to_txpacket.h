#ifndef _NUM_TO_TXPACKET
#define _NUM_TO_TXPACKET
#include "stm32f1xx_hal.h"
void num_to_tx(uint8_t *tx, uint32_t num);
#endif
