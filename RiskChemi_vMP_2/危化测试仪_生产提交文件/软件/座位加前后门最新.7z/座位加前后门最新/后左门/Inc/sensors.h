#ifndef __SENSORS_H
#define __SENSORS_H

#include "stm32f1xx_hal.h"
#include "prj_typedef.h"

void SensorsGetValue(SensorsTypeDef *pSensors);
#endif 
